<!DOCTYPE html>
<html>
<body>

<?php

$curl = curl_init();

$data = array(    
"merchant_id" => 'bp2igV9ORor9U1BgJVD8xWwF0omKvNQezSIIhpn5',
"limit" => '5',
);  
$url = "https://dev.quikipay.com/api/change-min-order-limit";

curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST,"POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

$response = curl_exec($curl);
curl_close($curl);

print_r($response);
?>

</body>
</html>