<!DOCTYPE html>
<html>
<body>
<form  method="post" enctype="multipart/form-data">
<input type="file" name="image" id="">
<input type="file" name="image2" id="">
<input type="submit" value="Post">
</form>
<?php

if(isset($_FILES['image']['tmp_name']) && isset($_FILES['image2']['tmp_name'])){
    $ch = curl_init();

    $cfile = new CURLFile($_FILES['image']['tmp_name'], $_FILES['image']['type'], $_FILES['image']['name']);
    $c2file = new CURLFile($_FILES['image2']['tmp_name'], $_FILES['image2']['type'], $_FILES['image2']['name']);  
    $data =array(
        "merchant_id" => 'bp2igV9ORor9U1BgJVD8xWwF0omKvNQezSIIhpn5',
        "receipt_upload" => $cfile,
        "customer_id_upload" => $c2file,
        "order_id" => "9878978811",
        "customer_email" => "haideralimughalers@gmail.com"
    );

    $url="https://dev.quikipay.com/api/document-re-upload";

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

    $response= curl_exec($ch);

    if($response == 'true') {
        echo 'file posted';
    }
    else{
        echo "Error: " . $curl_error($ch);
    }

}
?>

</body>
</html>