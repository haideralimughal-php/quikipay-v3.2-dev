<?php
$curl = curl_init();
$data = array(    
 "merchant_id"        => 'bp2igV9ORor9U1BgJVD8xWwF0omKvNQezSIIhpn5',
 "customer_email"     => 'haideralimughalers@gmail.com',
 "quantity"           => '200',
 "order_id"           => '98789788',
 "currency_symbol"    => 'CLP',
 "tx_id"              => 'tx_02',
 "site_url"           => 'https://example.store');    
$url = "https://dev.quikipay.com/api/fiat-order";
    
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST,"POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        
        $Response = curl_exec($curl);
        curl_close($curl);
        print_r($Response);
 ?>