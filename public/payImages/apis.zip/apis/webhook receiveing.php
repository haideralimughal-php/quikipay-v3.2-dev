
<?php
//Post method request receiving, 
    $tx_id=$_POST["tx_id"]; //kjsdh7868ds
    $payment_method=$_POST["payment_method"]; //fiat
    $order_id=$_POST["order_id"]; //876ads7y989
    $currency_symbol=$_POST["currency_symbol"]; //USD
    $quantity=$_POST["quantity"]; //amount e.g 10
    $deposit_at=$_POST["deposit_at"];//2021-01-04 02:10:02
    $status=$_POST["status"];  //pending,reject,completed
    $customer_email=$_POST["customer_email"]; //abc@gmail.com    customer email

     $update_order_query="update orders set status='$status' where order_id='$order_id' and transaction_id='$tx_id' and customer_email='$customer_email'";
     // run update query query as mentioned,
     //you have to check order_id and update status which is sent by Webhook
?>
